package com.example.schedule;

import androidx.appcompat.app.AppCompatActivity;


import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.view.View;
import android.widget.Button;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.material.textfield.TextInputEditText;
import com.vishnusivadas.advanced_httpurlconnection.PutData;

public class SignUp extends AppCompatActivity {
    TextView login;
    TextInputEditText TextInputEditTextEmail ,TextInputEditTextUsername,TextInputEditTextPassword;
    Button btnSign;
    ProgressBar progress;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_sign_up);

        TextInputEditTextEmail = findViewById(R.id.email);
        TextInputEditTextUsername = findViewById(R.id.username);
        TextInputEditTextPassword = findViewById(R.id.password);
        progress = findViewById(R.id.progress);
        btnSign =  findViewById(R.id.buttonsign);
        login = findViewById(R.id.login);

        login.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(getApplicationContext(), LogIn.class);
                startActivity(intent);
                overridePendingTransition(R.anim.left,R.anim.out_right);
                finish();
            }
        });

        btnSign.setOnClickListener(view -> {
            final String email,username,password;

            email = String.valueOf(TextInputEditTextEmail.getText());
            username = String.valueOf(TextInputEditTextUsername.getText());
            password = String.valueOf(TextInputEditTextPassword.getText());

            if(!email.equals("") && !username.equals("") && !password.equals("")) {
                progress.setVisibility(View.VISIBLE);
                Handler handler = new Handler(Looper.myLooper());
                handler.post(new Runnable() {
                    @Override
                    public void run() {

                        String[] field = new String[3];
                        field[0] = "email";
                        field[1] = "username";
                        field[2] = "password";

                        String[] data = new String[3];
                        data[0] = email;
                        data[1] = username;
                        data[2] = password;
                        PutData putData = new PutData("http://192.168.100.10/LoginRegister/signup.php", "POST", field, data);
                        if (putData.startPut()) {
                            if (putData.onComplete()) {
                                String result = putData.getResult();
                                progress.setVisibility(View.GONE);
                                if(result.equals("Sign Up Success")) {
                                    Toast.makeText(getApplicationContext(), result, Toast.LENGTH_SHORT).show();
                                    Intent intent = new Intent(SignUp.this, LogIn.class);
                                    startActivity(intent);
                                    overridePendingTransition(R.anim.left, R.anim.out_right);
                                    finish();
                                }
                                else {
                                    Toast.makeText(getApplicationContext(), result, Toast.LENGTH_SHORT).show();
                                }

                            }
                        }

                    }
                });
            }
            else {
                Toast.makeText(getApplicationContext(), "All fields are required", Toast.LENGTH_SHORT).show();
            }
        });

    }
}